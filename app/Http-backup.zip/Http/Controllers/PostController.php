<?php

namespace App\Http\Controllers;
use App\Http\Resources\PostResource;
use App\Http\Resources\LikeResource;
use App\Http\Resources\CommentLikeResource;
use App\Models\Post;
use App\Models\Likes;
use App\Models\CommentLike;
use App\Models\Comments;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\CommentReply;


class PostController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function allPosts()
    {
      return PostResource::collection(Post::orderBy('created_at', 'DESC')->where('status','1')
      ->orderBy('created_at', 'DESC')->get());
    }





    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function showPost($id)
    {
 $conditions=array(
    'status'=>'1',
    'id'=>$id
 );
        $post = Post::where($conditions)->first();
if($post){
    $response['responseMessage'] = 'success';
    $response['responseCode'] = 00;
    $post = Post::where($conditions)->first();
    $response['data'] = new PostResource($post);
    return response($response, 200);

}else{
    $response['responseMessage'] = 'unpublished';
    $response['responseCode'] = -1001;
    $response['data'] = [];
    return response($response, 200);
}

    }









    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function showPostLikes($id)
    {
 $conditions=array(
    'status'=>'1',
    'id'=>$id
 );
        $post = Post::where($conditions)->first();
if($post){
    $response['responseMessage'] = 'success';
    $response['responseCode'] = 00;
    $likes = Likes::where('post_id', $id)->get();
    $response['data'] = new LikeResource($likes);
    return response($response, 200);

}else{
    $response['responseMessage'] = 'failed';
    $response['responseCode'] = -1001;
    $response['data'] = [];
    return response($response, 200);
}

    }






















    /**
     * Show the form for creating a new resource.
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function likePost(Request $request)
    {

        $post_id= $request->post_id;
        $user_id=$request->user_id;


        $conditions =array(
            'post_id'=>$post_id,
            'user_id'=>$user_id
        );
        //check if user has liked previously
        $post = Likes::where($conditions)->first();
        if ($post) {
            Likes::where($conditions)->delete();
            $response['responseMessage'] = 'success';
        $response['responseCode'] = 00;
        $post = Post::where('id',$post_id)->first();
        $response['data'] = new PostResource($post);
        return response($response, 200);

        }else{
            $likes = new Likes();
            $likes->post_id = $post_id;
            $likes->user_id = $user_id;
            $likes->save();
            $response['responseMessage'] = 'success';
            $response['responseCode'] = 00;

            $post = Post::where('id',$post_id)->first();
            $response['data'] = new PostResource($post);
            return response($response, 200);
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function commentPost(Request $request)
    {
        $post_id= $request->post_id;
        $user_id=$request->user_id;
        $content=$request->content;
        $post = Post::findOrFail($post_id);
if( $post){
    $comments = new Comments();
    $comments->post_id = $post_id;
    $comments->user_id=$user_id;
    $comments->content=$content;
    $comments->save();
    $response['responseMessage'] = 'success';
    $response['responseCode'] = 00;
    $post = Post::where('id',$post_id)->first();
    $response['data'] = new PostResource($post);
    return response($response, 200);
}
        //
    }







     /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function replyComment(Request $request)
    {
        $post_id= $request->post_id;
        $comment_id= $request->comment_id;
        $user_id=$request->user_id;
        $content=$request->content;
        $comment = Comments::findOrFail($comment_id);

if( $comment){
    $comments = new CommentReply();
    $comments->comment_id = $comment_id;
    $comments->user_id=$user_id;
    $comments->content=$content;
    $comments->save();
    $response['responseMessage'] = 'success';
    $response['responseCode'] = 00;
    $post = Post::where('id',$post_id)->first();
    $response['data'] = new PostResource($post);
    return response($response, 200);
}else{

    $response['responseMessage'] = 'failed';
    $response['responseCode'] = -1001;
    $post = Post::where('id',$post_id)->first();
    $response['data'] = new PostResource($post);
    return response($response, 200);

}
        //
    }










    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function showCommentLikes($id)
    {

        $likes =  CommentLike::where('comment_id', $id)->get();

        if($likes){
            $response['responseMessage'] = 'success';
            $response['responseCode'] = 00;
            $response['data'] = new CommentLikeResource($likes);
            return response($response, 200);

        }else{
            $response['responseMessage'] = 'failed';
            $response['responseCode'] = -1001;
            $response['data'] = [];
            return response($response, 200);

        }




    }



















/**
     * Show the form for creating a new resource.
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function likeComment(Request $request)
    {

        $comment_id= $request->comment_id;
        $user_id=$request->user_id;
        $post_id=$request->post_id;

        $conditions =array(
            'comment_id'=>$comment_id,
            'user_id'=>$user_id
        );
        //check if user has liked previously
        $post = CommentLike::where($conditions)->first();
        if ($post) {
            CommentLike::where($conditions)->delete();
            $response['responseMessage'] = 'comment unliked';
        $response['responseCode'] = 00;
        $post = CommentLike::where('comment_id',$comment_id)->first();
        $response['data'] = new CommentLikeResource($post);
        return response($response, 200);

        }else{
            $likes = new CommentLike();
            $likes->comment_id = $comment_id;
            $likes->user_id = $user_id;
            $likes->save();
            $response['responseMessage'] = 'comment liked';
            $response['responseCode'] = 00;

            $like = CommentLike::where('comment_id',$comment_id)->get();
            $response['data'] = new CommentLikeResource($like);
            return response($response, 200);
        }
    }

























    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Post  $post
     * @return \Illuminate\Http\Response
     */
    public function edit(Post $post)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Post  $post
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Post $post)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Post  $post
     * @return \Illuminate\Http\Response
     */
    public function destroy(Post $post)
    {
        //
    }
}
